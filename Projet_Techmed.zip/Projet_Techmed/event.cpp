#include "event.h"
#include <QDebug>


event::event()
{
    int id = 1;
    emit receive_from_prog(id);
    id++;
}

void event::receive_from_prog(int value)
{
    if(value){
        qDebug()<<"event traité : ";
    }
}

/*void event::transmit_to_prog(int value)
{

}*/
