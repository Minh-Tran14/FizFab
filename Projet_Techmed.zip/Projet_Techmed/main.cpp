/* Créé et commenté par Minh-Tran NGUYEN et c'est tout - 08/2021 */

#include <QGuiApplication>
#include <QCoreApplication>
#include <QQmlApplicationEngine>
#include <QApplication>


#include "event.h"
#include "programme.h"

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

/** AFFICHAGE DU FICHIER QML
 *
 *  QQmlApplicationEngine engine;
    const QUrl url(QStringLiteral("qrc:/main.qml"));
    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();**/



    QCoreApplication a(argc, argv);
    programme prog; //appelle le fichier programme.cpp
    event event;  //appelle le fichier event.cpp

    /** CONNEXION DES SIGNAUX ET DES SLOTS **/
    QObject::connect(&prog,SIGNAL(transmit_to_event()),&event,SLOT(receive_from_prog()));
    //QObject::connect(&event,SIGNAL(transmit_to_prog()),&prog,SLOT(receive_from_event()));

    return a.exec();


}
