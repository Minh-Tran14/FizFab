#include "programme.h"

#include <iostream>
#include <QMessageBox>
#include <QApplication>
#include <QDebug>
using namespace std;

programme::programme()
{

    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()),this, SLOT(MyTimerSlot()));
    timer->start(2000);



/** LECTURE DU FICHIER XML EN ENTIER
 *
 *  QDomDocument dom("mon_xml"); //création du fichier dom nommé mon_xml
    QFile xml_doc("myXML.xml"); // On choisit le fichier contenant les informations XML.

    if(!xml_doc.open(QIODevice::ReadOnly)) // Si l'on n'arrive pas à ouvrir le fichier XML.
    {
        QMessageBox::warning(NULL,"Erreur à l'ouverture du document XML","Le document XML n'a pas pu être ouvert.");
        return;
    }
    if (!dom.setContent(&xml_doc)) // Si l'on n'arrive pas à associer le fichier XML à l'objet DOM.
    {
        xml_doc.close();
        QMessageBox::warning(NULL, "Erreur à l'ouverture du document XML", "Le document XML n'a pas pu être attribué à l'objet QDomDocument.");
        return;
    }

 xml_doc.close(); //fermeture du document XML : on n'en a plus besoin, tout est compris dans l'objet DOM.


// INITIALISATION DES ENFANTS
    QDomElement dom_element = dom.documentElement();
    QDomNode noeud = dom_element.firstChild(); //récupération du premier enfant correspondant au head et aux étapes dans le fichier xml
    QDomElement child = noeud.toElement(); // Transformation du noeud en élément
    QDomNode noeud2 = child.firstChild(); // 2è enfant correspondant aux event D,C et I
    QDomElement grandchild = noeud2.toElement();
    QDomNode noeud3 = grandchild.firstChild(); //3è enfant correspondant aux events/conditions
    QDomElement event = noeud3.toElement();
    QDomNode noeud4 = event.firstChild(); //4è enfant correspondant aux sous events
    QDomElement event1 = noeud4.toElement();



    i = 0; //variable permettant d'incrémenter les étapes

//AFFICHAGE DE L'ENTETE ET SA DESCRIPTION
    if(child.attribute("ID").toInt() == 01)
    {
        qDebug() << "Titre : " + child.attribute("titre");
        qDebug() << "Description : " + child.attribute("description");
        noeud = noeud.nextSibling(); //passage etape suivante
    }

//BOUCLE DES ETAPES
    while(!noeud.isNull())
    {
        child = noeud.toElement();
        if(child.attribute("ID").toInt() == i)
        {
            qDebug() << "étape n°" + child.attribute("ID");


       //BOUCLE DES EVENTS D,C ET I
            noeud2 = child.firstChild();
            while(!noeud2.isNull()){
                QDomElement grandchild = noeud2.toElement();

                //LECTURE EVENT D
                if(grandchild.tagName()== "eventD"){
                    ids = 1; // variable permettant d'incrémenter les id des events, on commence à 1
                    qDebug() << grandchild.attribute("ID");

                    //boucle lisant les events dans l'event D
                    noeud3 = grandchild.firstChild();
                    while(!noeud3.isNull())
                    {
                        event = noeud3.toElement();
                        if(event.attribute("id").toInt() == ids)
                        {
                            //QMessageBox::information(NULL, "event", "EVENT n° " + event.attribute("id","?") + "<br />ordre donné : " + event.attribute("ordre")+ "<br />zone : " + event.attribute("zone") + "<br />label : " +event.attribute("label") + "<br />tableau : " +event.attribute("tab")+ "<br />variable : " + event.attribute("var"));
                            qDebug() << "EVENT n°" + event.attribute("id","?");
                            qDebug() << "ordre : " + event.attribute("ordre");
                            ids++;
                            noeud3 = noeud3.nextSibling(); //passage aux events suivants
                        }
                    }
                    noeud2 = noeud2.nextSibling(); //passage à l'event C
                }

                //LECTURE EVENT C
                if(grandchild.tagName()== "eventC"){
                    ids = 1;
                    s = 0; //variable permettant d'incrémenter les sous events
                    qDebug() << grandchild.attribute("ID");

                    //boucle lisant les events dans l'event C
                    noeud3 = grandchild.firstChild();
                    while(!noeud3.isNull()){
                        event = noeud3.toElement();
                        if(event.attribute("id").toInt() == ids)
                        {
                            //QMessageBox::information(NULL, "event", "CONDITION n° " + event.attribute("id","?") + "<br />ordre donné : " + event.attribute("ordre"));
                            qDebug() << "CONDITION n°" + event.attribute("id","?");
                            qDebug() << "ordre : " + event.attribute("ordre");

                            //boucle lisant les sous events dans l'event C
                            noeud4 = event.firstChild();
                            while(!noeud4.isNull())
                            {
                                event1 = noeud4.toElement();
                                if(event1.attribute("id").toInt() == s)
                                {
                                    //QMessageBox::information(NULL, "event", "EVENT n° " + event1.attribute("id","?") + "<br />ordre donné : " + event1.attribute("ordre"));
                                    qDebug() << "EVENT n°" + event1.attribute("id","?");
                                    qDebug() << "ordre : " + event1.attribute("ordre");
                                    s++;
                                    noeud4 = noeud4.nextSibling(); //passage au sous event suivant
                                }
                            }
                            ids++;
                            noeud3 = noeud3.nextSibling(); //passage à l'event suivant dans l'event C
                        }
                    }
                    noeud2 = noeud2.nextSibling(); //passage à l'event I
                }

                //LECTURE EVENT I
                if(grandchild.tagName()== "eventI"){
                    ids = 1;
                    s = 0;
                    qDebug() << grandchild.attribute("ID");

                    //boucle lisant les events dans l'event I
                    noeud3 = grandchild.firstChild();
                    while(!noeud3.isNull()){
                        event = noeud3.toElement();
                        if(event.attribute("id").toInt() == ids)
                        {
                           // QMessageBox::information(NULL, "event", "CONDITION n° " + event.attribute("id","?") + "<br />ordre donné : " + event.attribute("ordre"));
                            qDebug() << "CONDITION n°" + event.attribute("id","?");
                            qDebug() << "ordre : " + event.attribute("ordre");

                            //boucle lisant les sous events dans l'event I
                            noeud4 = event.firstChild();
                            while(!noeud4.isNull())
                            {
                                event1 = noeud4.toElement();
                                if(event1.attribute("id").toInt() == s)
                                {
                                    //QMessageBox::information(NULL, "event", "EVENT n° " + event1.attribute("id","?") + "<br />ordre donné : " + event1.attribute("ordre"));
                                    qDebug() << "EVENT n°" + event1.attribute("id","?");
                                    qDebug() << "ordre : " + event1.attribute("ordre");
                                    s++;
                                    noeud4 = noeud4.nextSibling(); //passage au sous event suivant
                                }
                            }
                            ids++;
                            noeud3 = noeud3.nextSibling();  //passage à l'event suivant dans l'event I
                        }
                    }
                    noeud2 = noeud2.nextSibling();
                }
            }

            i++;
            noeud = noeud.nextSibling(); //passage etape suivante

        }
    }
    **/

}



/** FONCTION TIMER QUI BOUCLE SUR L'EVENT D DANS L'ETAPE 0 **/

void programme::MyTimerSlot()
{
    QDomDocument dom("mon_xml");
    QFile xml_doc("myXML.xml"); // On choisit le fichier contenant les informations XML.

    if(!xml_doc.open(QIODevice::ReadOnly)) // Si l'on n'arrive pas à ouvrir le fichier XML.
    {
         QMessageBox::warning(NULL,"Erreur à l'ouverture du document XML","Le document XML n'a pas pu être ouvert.");
         return;
    }
    if (!dom.setContent(&xml_doc)) // Si l'on n'arrive pas à associer le fichier XML à l'objet DOM.
    {
        xml_doc.close();
        QMessageBox::warning(NULL, "Erreur à l'ouverture du document XML", "Le document XML n'a pas pu être attribué à l'objet QDomDocument.");
        return;
    }

    xml_doc.close(); // Dans tous les cas, on doit fermer le document XML : on n'en a plus besoin, tout est compris dans l'objet DOM.


        QDomElement dom_element = dom.documentElement();
        QDomNode noeud = dom_element.firstChild();
        QDomElement child = noeud.toElement(); // Transformation du noeud en élément
        QDomNode noeud2 = child.firstChild();
        QDomElement grandchild = noeud2.toElement();
        QDomNode noeud3 = grandchild.firstChild();
        QDomElement event = noeud3.toElement();



        if(child.attribute("ID").toInt() == 01)
        {
            qDebug() << "Titre : " + child.attribute("titre");
            qDebug() << "Description : " + child.attribute("description");
            noeud = noeud.nextSibling();
        }

        child = noeud.toElement();
        if(child.attribute("ID").toInt() == 0)
        {
            qDebug() << "étape n°" + child.attribute("ID");
            noeud2 = child.firstChild();
            while(!noeud2.isNull()){
                QDomElement grandchild = noeud2.toElement();
                if(grandchild.tagName()== "eventD"){
                    ids = 1; // On initialise ids à 1
                    qDebug() << grandchild.attribute("ID");
                    noeud3 = grandchild.firstChild();
                    while(!noeud3.isNull())
                    {
                        event = noeud3.toElement();
                        if(event.attribute("id").toInt() == ids)
                        {
                            qDebug() << "EVENT n°" + event.attribute("id","?");
                            qDebug() << "ordre : " + event.attribute("ordre");
                            emit transmit_to_event(ids);
                            ids++;
                            noeud3 = noeud3.nextSibling();
                        }
                    }

                 }
            }
        }


}


/** Récupère l'id des events **/
void programme::transmit_to_event(int value)
{
    if(value){ qDebug() << "event id = " << value;}
    else { qDebug() << "error";}

}


/** censé récupérer la valeur transmise par event et passe à l'event suivant mais j'ai pas encore trouvé la solution **/
void programme::receive_from_event(int value)
{
    QDomDocument dom("mon_xml");
    QFile xml_doc("myXML.xml");

    QDomElement dom_element = dom.documentElement();
    QDomNode noeud = dom_element.firstChild();
    QDomElement child = noeud.toElement();
    QDomNode noeud2 = child.firstChild();
    QDomElement grandchild = noeud2.toElement();


    if(value==9){
        noeud2 = noeud2.nextSibling();
        qDebug() << grandchild.attribute("ID");
    }

}

