#ifndef PROGRAMME_H
#define PROGRAMME_H

#include <QMainWindow>
#include <QtXml>
#include <QTimer>



class programme : public QObject
{
    Q_OBJECT
public:
    programme();
    QTimer *timer;

public slots:
    void MyTimerSlot();
    void receive_from_event(int value);

signals:
    void transmit_to_event(int value);

private:
    QFile xml_doc;
    QDomElement dom;
    QDomNode noeud;
    QDomElement element;
    int ids;
    int i;
    int s;

};

#endif // PROGRAMME_H
