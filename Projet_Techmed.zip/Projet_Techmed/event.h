#ifndef EVENT_H
#define EVENT_H

#include <QMainWindow>


class event : public QObject
{
    Q_OBJECT
public:
    event();

public slots :
    void receive_from_prog(int value);

signals :
    //void transmit_to_prog();

private :



};

#endif // EVENT_H
